# Semantic Validator SDK for TypeScript

TypeScript client for the Semantic Validator REST API. Requires Node.js 18 or newer and uses the built in `fetch` API.

## Install locally

From this directory:

```bash
npm install
npm run build
```

In an application in the same repository, install the generated package with:

```bash
npm install ../path/to/proyecto-validator/sdk/typescript
```

## Use

```ts
import { Validator } from "@semantic-validator/sdk";

const validator = new Validator({
  apiKey: process.env.SEMANTIC_VALIDATOR_API_KEY!,
  baseURL: "http://localhost:8080",
});

const result = await validator.name("Jorge Eduardo");
console.log(result.valid, result.confidence, result.status);

const answer = await validator.check(
  "Necesito devolver el producto porque llegó roto",
  "¿El cliente está solicitando una devolución?",
);
console.log(answer.valid);

const batch = await validator.validateBatch([
  { id: "name", rule: "person_name", value: "Jorge Eduardo" },
  { id: "invalid-name", rule: "person_name", value: "sdgfxcdg" },
]);
console.log(batch);
```

The SDK sends `Authorization: Bearer <apiKey>`. Keep the Semantic Validator key on your server; never expose it in browser code. `valid` can be `null` when the semantic result is uncertain. HTTP and transport failures throw `SemanticValidatorError`, which exposes `code` and, for HTTP errors, `statusCode`.
