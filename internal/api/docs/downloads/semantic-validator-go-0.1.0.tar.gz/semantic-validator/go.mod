module semantic-validator

go 1.22
