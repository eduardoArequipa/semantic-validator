# Semantic Validator Go SDK

Go client for the Semantic Validator API. It uses only the Go standard library.

```go
package main

import (
	"context"
	"fmt"
	"log"
	"os"

	validator "semantic-validator/sdk/go"
)

func main() {
	client := validator.NewClient(os.Getenv("SEMANTIC_VALIDATOR_API_KEY"))
	result, err := client.Name(context.Background(), "Jorge Eduardo")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println(result.Valid, result.Confidence, result.Status)
}
```

`NewClient` uses `http://localhost:8080` with a 30-second timeout. Use `NewClientWithOptions` to set a different base URL, timeout, or reusable `http.Client`. The methods `Validate`, `Name`, `Check`, and `ValidateBatch` accept a context. An uncertain result has `Valid == nil`; per-item batch errors are returned in `BatchResult.Error`. API-level HTTP failures can be inspected with `errors.As(err, &apiErr)` where `apiErr` is `*validator.APIError`.
