from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Optional


class SemanticValidatorError(Exception):
    """Error returned by Semantic Validator or raised by the SDK transport."""

    def __init__(self, message: str, *, code: str = "client_error", status_code: Optional[int] = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code


@dataclass(frozen=True)
class ValidationResult:
    valid: Optional[bool]
    confidence: float
    status: str

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "ValidationResult":
        try:
            return cls(
                valid=payload["valid"],
                confidence=float(payload["confidence"]),
                status=str(payload["status"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise SemanticValidatorError("invalid validation response", code="invalid_response") from exc


@dataclass(frozen=True)
class BatchItem:
    id: str
    rule: str
    value: str

    def to_payload(self) -> dict[str, str]:
        return {"id": self.id, "rule": self.rule, "value": self.value}


@dataclass(frozen=True)
class BatchResult:
    id: str
    valid: Optional[bool]
    confidence: float
    status: str
    error: Optional[dict[str, str]] = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "BatchResult":
        try:
            error = payload.get("error")
            return cls(
                id=str(payload["id"]),
                valid=payload.get("valid"),
                confidence=float(payload.get("confidence", 0)),
                status=str(payload["status"]),
                error=error if isinstance(error, dict) else None,
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise SemanticValidatorError("invalid batch response", code="invalid_response") from exc


Opener = Callable[..., Any]


class Validator:
    """Synchronous client for the Semantic Validator API."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "http://localhost:8080",
        timeout: float = 30.0,
        opener: Optional[Opener] = None,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._opener = opener or urllib.request.urlopen

    def validate(self, rule: str, value: str) -> ValidationResult:
        payload = self._post("/v1/validate", {"rule": rule, "value": value})
        return ValidationResult.from_payload(payload)

    def name(self, value: str) -> ValidationResult:
        return self.validate("person_name", value)

    def check(self, value: str, question: str) -> ValidationResult:
        payload = self._post("/v1/check", {"value": value, "question": question})
        return ValidationResult.from_payload(payload)

    def validate_batch(self, items: Iterable[BatchItem | Mapping[str, str]]) -> list[BatchResult]:
        normalized = [self._normalize_batch_item(item) for item in items]
        if not 1 <= len(normalized) <= 100:
            raise ValueError("items must contain between 1 and 100 elements")
        payload = self._post("/v1/validate/batch", {"items": [item.to_payload() for item in normalized]})
        response_items = payload.get("items")
        if not isinstance(response_items, list):
            raise SemanticValidatorError("invalid batch response", code="invalid_response")
        return [BatchResult.from_payload(item) for item in response_items]

    def _normalize_batch_item(self, item: BatchItem | Mapping[str, str]) -> BatchItem:
        if isinstance(item, BatchItem):
            return item
        if isinstance(item, Mapping):
            try:
                return BatchItem(id=str(item["id"]), rule=str(item["rule"]), value=str(item["value"]))
            except KeyError as exc:
                raise ValueError(f"batch item requires {exc.args[0]}") from exc
        raise TypeError("batch items must be BatchItem instances or mappings")

    def _post(self, path: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self._base_url + path,
            data=body,
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            response = self._opener(request, timeout=self._timeout)
            raw_body = response.read()
        except urllib.error.HTTPError as exc:
            raw_body = exc.read()
            raise self._error_from_body(raw_body, exc.code) from exc
        except urllib.error.URLError as exc:
            raise SemanticValidatorError(f"request failed: {exc.reason}", code="transport_error") from exc
        except TimeoutError as exc:
            raise SemanticValidatorError("request timed out", code="timeout") from exc
        finally:
            if "response" in locals() and hasattr(response, "close"):
                response.close()

        try:
            decoded = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise SemanticValidatorError("server returned invalid JSON", code="invalid_response") from exc
        if not isinstance(decoded, dict):
            raise SemanticValidatorError("server returned an invalid response", code="invalid_response")
        return decoded

    @staticmethod
    def _error_from_body(body: bytes, status_code: int) -> SemanticValidatorError:
        try:
            decoded = json.loads(body.decode("utf-8"))
            error = decoded.get("error", {})
            code = str(error.get("code", "http_error"))
            message = str(error.get("message", "request failed"))
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError):
            code = "http_error"
            message = "request failed"
        return SemanticValidatorError(message, code=code, status_code=status_code)
